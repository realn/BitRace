=====================================
	BIT RACE README

CodeRulers 2007
=====================================

I.	INSTALACJA
II.	ZASADY GRY
III.	CREDITS

/////////////////////////////////////

I.	INSTALACJA

Ca�a instalacja gry zamyka si� do przekopiowania
pliku exe oraz dw�ch plik�w fgx (zawartych w 
archiwum) do zamierzonego folderu i uruchomieniu
gry. Podczas pierwszego uruchomienia pojawi� si�
trzy dodatkowe pliki, kt�rych nie nale�y modyfikowa�.

Minimalne wymagania:

Procesor:  300 MHz lub szybszy
Pami�� RAM:	64 MB lub wi�cej
Karta graficzna: Dowolna obs�uguj�ca OpenGL w wersji 1.1
System Operacyjny:	Windows 2000/XP
			Windows 98 SE (NIE TESTOWANE)
DirectX:	DirectX 9.0 lub nowszy

/////////////////////////////////////

II.	ZASADY GRY

T�o:
Wcielamy si� w program p2p na trudnej drodze
do �ci�gania jak najwi�kszej ilo�ci danych. Im
wi�cej uda si� pozyska� tym lepiej.

Zasady:
G��wnym celem gry jest zdoby� jak najwi�cej punkt�w.
Mo�na to osi�gn�� zbieraj�c z�te sze�ciany, lub niszcz�c
nacieraj�cych wrog�w.
Gra si� ko�czy, gdy na skutek odniesionych uszkodze�
(kt�re reprezentuje zmniejszaj�cy si� czerwony pasek)
�ycie spadnie poni�ej zera.
Obra�enia otrzymuje si� na skutek dotkni�cia wroga, a odzyskuje
si� zbieraj�c sze�ciany.
Wrog�w s� trzy rodzaje:
- Fioletowe obracaj�ce si� w miejscu "CRC error"
	nie ruszaj� si�, ale mog� wyst�powa� w du�ych ilo�ciach.
- Fioletowe "Script Kiddies"
	ruszaj� w kierunku gracza, ma�o zwrotne, ale mog� zaskoczy�
- Czerwone, Du�e "H4X0Ry"
	ruszj� si� szybko w stron� gracza, du�a zwrotno��, i obra�enia te� spore

Po zako�czeniu gry mo�na uzyska� wpis na list� najwy�szych wynik�w,
na kt�r� mo�na mie� potem dost�p przez g��wne menu.

/////////////////////////////////////

III.	CREDITS

Gra w ca�o�ci zaprojektowana i wykonana przez Real_Noname'a :D

Za uwagi co do gry dzi�kuje u�ytkownikom Warsztatu.

CodeRulers 2007 - www.coderulers.info